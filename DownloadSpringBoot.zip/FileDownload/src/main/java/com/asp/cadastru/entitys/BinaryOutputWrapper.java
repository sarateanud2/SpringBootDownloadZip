package com.asp.cadastru.entitys;

import org.springframework.http.HttpHeaders;

public class BinaryOutputWrapper {
	
	private byte[] data;
	private HttpHeaders headers;

	public BinaryOutputWrapper(byte[] data, HttpHeaders headers) {
		super();
		this.data = data;
		this.headers = headers;
	}
	
	

	public BinaryOutputWrapper(byte[] data) {
		super();
		this.data = data;
	}



	public BinaryOutputWrapper() {
		super();
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public HttpHeaders getHeaders() {
		return headers;
	}

	public void setHeaders(HttpHeaders headers) {
		this.headers = headers;
	}

	

}
