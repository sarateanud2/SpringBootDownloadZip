package com.asp.cadastru.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.asp.cadastru.entitys.BinaryOutputWrapper;


@RestController
@CrossOrigin("*")
public class FileController {
	
	@RequestMapping(value = "/download/{fileNames}", method = RequestMethod.GET)
	public void downloadFiles(@PathVariable String fileNames) {
		String[] filesArray = fileNames.split("\\$");
		for(String fileName : filesArray) {
			try {
				System.out.println(fileName);
				this.download(fileName);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	
	public ResponseEntity<Object> download( String fileName) throws IOException {
		String pathFile = "F:\\Study\\template\\interior-design\\images\\";
		System.out.println(pathFile + fileName);

		File file = new File(pathFile + fileName);

	    InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

	    return ResponseEntity.ok()
	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
	            .contentLength(file.length())
	            .contentType(MediaType.parseMediaType("application/octet-stream"))
	            .body(resource);
	}
	
	public ResponseEntity<Object> download2( String fileName) throws IOException {
		String pathFile = "F:\\Study\\template\\interior-design\\images\\";
		System.out.println(pathFile + fileName);

		File file = new File(pathFile + fileName);

	    InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

	    return ResponseEntity.ok()
	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
	            .contentLength(file.length())
	            .contentType(MediaType.parseMediaType("application/octet-stream"))
	            .body(resource);
	}
	
	
	
	
	//Create ZipFile
	@RequestMapping(value = "/zipfile/{fileNames}", method = RequestMethod.GET)
	public void createZipForDownloadFiles(@PathVariable String fileNames) throws IOException {
		String pathFile = "F:\\Study\\template\\interior-design\\images\\";
		List<String> srcFiles = new ArrayList<>();
		String[] filesArray = fileNames.split("\\$");
		for(String fileName : filesArray) {
			srcFiles.add(pathFile + fileName);
		}
		BinaryOutputWrapper output = new BinaryOutputWrapper(); 
		
        FileOutputStream fos = new FileOutputStream("F:\\Study\\template\\interior-design\\images\\multiCompressed.zip");
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        for (String srcFile : srcFiles) {
            File fileToZip = new File(srcFile);
            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
            zipOut.putNextEntry(zipEntry);
 
            byte[] bytes = new byte[1024];
            int length;
            while((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        fos.close();
	}
	
	
		
}
