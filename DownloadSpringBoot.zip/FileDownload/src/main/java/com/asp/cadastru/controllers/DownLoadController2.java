package com.asp.cadastru.controllers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.asp.cadastru.entitys.BinaryOutputWrapper;

@RestController
public class DownLoadController2 {

	 public BinaryOutputWrapper prepDownloadAsZIP(List<String> filenames) throws IOException {
	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.parseMediaType("application/zip"));
	        String outputFilename = "output888.zip";
	        headers.setContentDispositionFormData(outputFilename, outputFilename);
//	        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

	        ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
	        ZipOutputStream zipOutputStream = new ZipOutputStream(byteOutputStream);

	        for(String filename: filenames) {
	            File file = new File(filename); 
	            zipOutputStream.putNextEntry(new ZipEntry(filename));           
	            FileInputStream fileInputStream = new FileInputStream(file);
	            IOUtils.copy(fileInputStream, zipOutputStream);
	            fileInputStream.close();
	            zipOutputStream.closeEntry();
	        }           
	        zipOutputStream.close();
	        return new BinaryOutputWrapper(byteOutputStream.toByteArray(), headers); 
	    }
	 
	 @RequestMapping(value = "/testDowload/{filesName}")
	 public ResponseEntity<?> generatePDF(@PathVariable String filesName) {
	     BinaryOutputWrapper output = new BinaryOutputWrapper();
	     String pathFile = "F:\\Study\\template\\interior-design\\images\\";
	     List<String> srcFiles = new ArrayList<>();
		String[] filesArray = filesName.split("\\$");
		for(String fileName : filesArray) {
			srcFiles.add(pathFile + fileName);
		}
	     
	     
	     try {
//	         String inputFile = "sample.pdf"; 
	         output = this.prepDownloadAsZIP(srcFiles);
	         //or invoke prepDownloadAsZIP(...) with a list of filenames
	     } catch (IOException e) {
	         e.printStackTrace();
	         //Do something when exception is thrown
	     } 
	     return new ResponseEntity<>(output.getData(), output.getHeaders(), HttpStatus.OK); 
	 }
	 
	 
	 //////////////////////////////////////////////////////////////////////////////////////////////////
	 //---- BestSolution ----
//////////////////////////////////////////////////////////////////////////////////////////////////
	 
	 
	 @RequestMapping(value="/zip/{filesName}", produces="application/zip")
	 public void zipFiles(HttpServletResponse response, @PathVariable String filesName) throws IOException {

	     //setting headers  
	     response.setStatus(HttpServletResponse.SC_OK);
	     response.addHeader("Content-Disposition", "attachment; filename=\"test.zip\"");

	     ZipOutputStream zipOutputStream = new ZipOutputStream(response.getOutputStream());

	     // create a list to add files to be zipped
	     ArrayList<File> files = new ArrayList<>(2);
//	     files.add(new File("README.md"));
	     String pathFile = "F:\\Study\\template\\interior-design\\images\\";
	     List<File> srcFiles = new ArrayList<>();
		String[] filesArray = filesName.split("\\$");
		for(String fileName : filesArray) {
			srcFiles.add(new File(pathFile + fileName));
		}

	     // package files
	     for (File file : srcFiles) {
	         //new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
	         zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
	         FileInputStream fileInputStream = new FileInputStream(file);

	         IOUtils.copy(fileInputStream, zipOutputStream);

	         fileInputStream.close();
	         zipOutputStream.closeEntry();
	     }    

	     zipOutputStream.close();
	 }
	 
	 
	 
	 
	 
	 
	 
}
